import os
import time
from datetime import datetime
from flask import Flask, render_template, request, jsonify, make_response, redirect, url_for
from flask_caching import Cache

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'travel-seo-secret-2026')

app.config.from_mapping({"CACHE_TYPE": "SimpleCache", "CACHE_DEFAULT_TIMEOUT": 86400})
cache = Cache(app)

from services.ai_logic import generate_guide, get_related_destinations, get_meta_description
from services.translations import get_translations, TRANSLATIONS

# ── Language config ───────────────────────────────────────────────────────────
SUPPORTED_LANGUAGES = {
    "en": {"name": "English", "dir": "ltr", "label": "EN", "flag": "🇬🇧"},
    "de": {"name": "Deutsch", "dir": "ltr", "label": "DE", "flag": "🇩🇪"},
    "es": {"name": "Español", "dir": "ltr", "label": "ES", "flag": "🇪🇸"},
    "fr": {"name": "Français", "dir": "ltr", "label": "FR", "flag": "🇫🇷"},
    "ar": {"name": "العربية", "dir": "rtl", "label": "AR", "flag": "🇸🇦"},
}

TOP_10_CITIES = ["London", "Dubai", "Paris", "New York", "Tokyo",
                 "Barcelona", "Rome", "Amsterdam", "Bangkok", "Istanbul"]

TOP_100_CITIES = [
    "Paris", "Tokyo", "New York", "Dubai", "London", "Barcelona", "Rome", "Amsterdam",
    "Bangkok", "Bali", "Singapore", "Sydney", "Istanbul", "Prague", "Vienna", "Berlin",
    "Madrid", "Lisbon", "Athens", "Cairo", "Mumbai", "Delhi", "Shanghai", "Beijing",
    "Seoul", "Kuala Lumpur", "Hong Kong", "Taipei", "Oslo", "Stockholm", "Copenhagen",
    "Helsinki", "Zurich", "Geneva", "Brussels", "Budapest", "Warsaw", "Krakow", "Dubrovnik",
    "Santorini", "Mykonos", "Florence", "Milan", "Venice", "Naples", "Marrakech",
    "Casablanca", "Nairobi", "Cape Town", "Johannesburg", "Accra", "Lagos", "Dakar",
    "Tunis", "Algiers", "Beirut", "Amman", "Riyadh", "Jeddah", "Abu Dhabi", "Doha",
    "Muscat", "Karachi", "Lahore", "Colombo", "Kathmandu", "Dhaka", "Yangon", "Hanoi",
    "Ho Chi Minh City", "Phnom Penh", "Manila", "Jakarta", "Denpasar", "Auckland",
    "Melbourne", "Brisbane", "Perth", "Toronto", "Montreal", "Vancouver", "Mexico City",
    "Cancun", "Buenos Aires", "Santiago", "Lima", "Bogota", "Rio de Janeiro",
    "Sao Paulo", "Cartagena", "Havana", "San Jose", "Panama City", "Miami", "Las Vegas",
    "Los Angeles", "San Francisco", "Chicago", "Washington DC", "Boston", "New Orleans",
]

# ── Helpers ───────────────────────────────────────────────────────────────────
def city_to_slug(city: str) -> str:
    return city.lower().replace(" ", "-")

def slug_to_city(slug: str) -> str:
    return slug.replace("-", " ").title()

def detect_language(accept_lang: str | None) -> str:
    """
    Parse the browser's Accept-Language header and return the best matching
    supported language code (defaulting to 'en').
    Example header: 'ar,en;q=0.9,fr;q=0.8'
    """
    if not accept_lang:
        return "en"
    candidates = []
    for segment in accept_lang.split(","):
        segment = segment.strip()
        if ";q=" in segment:
            code, _, q_str = segment.partition(";q=")
            try:
                q = float(q_str)
            except ValueError:
                q = 0.0
        else:
            code, q = segment, 1.0
        # Normalise: take first two chars, lower-case
        code = code.strip().split("-")[0].lower()
        candidates.append((code, q))
    candidates.sort(key=lambda x: x[1], reverse=True)
    for code, _ in candidates:
        if code in SUPPORTED_LANGUAGES:
            return code
    return "en"

# ── City background images (curated Unsplash photo IDs) ─────────────────────
# Direct CDN URLs work without an API key. The fallback uses a gradient.
_CITY_PHOTOS = {
    "paris":          "photo-1502602898657-3e91760cbb34",
    "tokyo":          "photo-1540959733332-eab4deabeeaf",
    "new-york":       "photo-1496442226666-8d4d0e62e6e9",
    "dubai":          "photo-1512453979798-5ea266f8880c",
    "london":         "photo-1513635269975-59663e0ac1ad",
    "barcelona":      "photo-1583422409516-2895a77efb16",
    "rome":           "photo-1529260830199-42c24126f198",
    "amsterdam":      "photo-1534351590666-13e3e96b5017",
    "bangkok":        "photo-1555400038-63f5ba517a47",
    "bali":           "photo-1537996194471-e657df975ab4",
    "singapore":      "photo-1525625293386-3f8f99389edd",
    "sydney":         "photo-1506973035872-a4ec16b8e8d9",
    "istanbul":       "photo-1527838832700-5059252407fa",
    "prague":         "photo-1541849546-216549ae216d",
    "vienna":         "photo-1516550135131-0a34a6f9a46a",
    "berlin":         "photo-1560969184-10fe8719e047",
    "madrid":         "photo-1543783207-ec64e4d95325",
    "lisbon":         "photo-1555881400-74d7acaacd8b",
    "athens":         "photo-1555993539-1732b0258235",
    "cairo":          "photo-1572252009286-268acec5ca0a",
    "budapest":       "photo-1570637484682-a5c7f15758cd",
    "kyoto":          "photo-1545569341-9eb8b30979d9",
    "osaka":          "photo-1590559899731-a382839e5549",
    "florence":       "photo-1513581166391-887a96ddeafd",
    "venice":         "photo-1514890547357-a9ee288728e0",
    "milan":          "photo-1610016302534-6f67f1c968d8",
    "marrakech":      "photo-1539020140153-e479b8b3c2f0",
    "santorini":      "photo-1533105079780-92b9be482077",
    "hong-kong":      "photo-1531259683007-016a7b628fc3",
    "seoul":          "photo-1534008757030-27299c4371b6",
    "shanghai":       "photo-1538428494232-9c0d8a3ab403",
    "beijing":        "photo-1508804185872-d7badad00f7d",
    "doha":           "photo-1577717903315-1691ae25ab3f",
    "abu-dhabi":      "photo-1512632578888-169bbbc64f33",
    "miami":          "photo-1533106497176-45ae19e68ba2",
    "las-vegas":      "photo-1506905925346-21bda4d32df4",
    "los-angeles":    "photo-1444723121867-7a241cacace9",
    "toronto":        "photo-1517090504586-fde19ea6066f",
    "cancun":         "photo-1552074284-5e88ef1aef18",
    "rio-de-janeiro": "photo-1483729558449-99ef09a8c325",
    "buenos-aires":   "photo-1580051890867-fc91c50a1fcb",
    "cape-town":      "photo-1580060839134-75a5edca2e99",
    "nairobi":        "photo-1611348524140-53c9a25263d6",
    "kuala-lumpur":   "photo-1596422846543-75c6fc197f07",
    "mexico-city":    "photo-1585464231875-d9ef1f5ad396",
    "montreal":       "photo-1558618666-fcd25c85cd64",
    "vancouver":      "photo-1559511260-10d917f40a7c",
    "chicago":        "photo-1477959858617-67f85cf4f1df",
    "san-francisco":  "photo-1501594907352-04cda38ebc29",
    "washington-dc":  "photo-1501466044931-62695aada8e9",
    "new-orleans":    "photo-1568702846914-96b305d2aaeb",
    "lima":           "photo-1531968455001-5c5272a41129",
    "bogota":         "photo-1533152177671-da48bbbab12e",
}

def get_city_image(city_slug: str) -> str | None:
    """Return an Unsplash CDN image URL for the city, or None (uses CSS gradient fallback)."""
    photo_id = _CITY_PHOTOS.get(city_slug)
    if photo_id:
        return (
            f"https://images.unsplash.com/{photo_id}"
            "?w=1920&q=80&auto=format&fit=crop&crop=entropy"
        )
    return None

def get_seo_title(city: str, language: str = "en") -> str:
    year = datetime.now().year
    titles = {
        "en": f"Is {city} Expensive? [{year}] Budget Guide & Insider Secrets",
        "de": f"Ist {city} teuer? [{year}] Reise-Budgetführer & Insider-Tipps",
        "es": f"¿Es caro {city}? [{year}] Guía de Presupuesto & Secretos Insider",
        "fr": f"{city} est-elle chère ? [{year}] Guide Budget & Secrets d'Initiés",
        "ar": f"هل {city} غالية؟ [{year}] دليل الميزانية والنصائح الداخلية",
    }
    return titles.get(language, titles["en"])

def _base_ctx(lang: str) -> dict:
    """Common context injected into every render_template call."""
    t = get_translations(lang)
    return {
        "languages": SUPPORTED_LANGUAGES,
        "language": lang,
        "lang_info": SUPPORTED_LANGUAGES[lang],
        "t": t,
        "top_cities": TOP_10_CITIES,
        "year": datetime.now().year,
    }

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    # 1. Explicit ?lang=xx overrides auto-detection
    lang = request.args.get("lang", "").strip().lower()
    if lang not in SUPPORTED_LANGUAGES:
        # 2. Auto-detect from browser header
        lang = detect_language(request.headers.get("Accept-Language"))
    # 3. If not English (default), redirect to language-prefixed homepage
    if lang != "en":
        return redirect(f"/{lang}/", 302)
    return render_template("index.html", **_base_ctx(lang))

@app.route("/<lang>/")
def index_lang(lang):
    if lang not in SUPPORTED_LANGUAGES:
        return redirect("/", 302)
    return render_template("index.html", **_base_ctx(lang))

# Legacy: /guide/<city>?lang=xx  →  /<lang>/guide/<city>
@app.route("/guide/<city>")
def guide_legacy(city):
    lang = request.args.get("lang", "en")
    if lang not in SUPPORTED_LANGUAGES:
        lang = "en"
    return redirect(url_for("guide", lang=lang, city=city), 301)

@app.route("/<lang>/guide/<city>")
def guide(lang, city):
    if lang not in SUPPORTED_LANGUAGES:
        return redirect(url_for("guide", lang="en", city=city), 301)

    city_display = slug_to_city(city)
    city_slug = city_to_slug(city_display)

    cache_key = f"guide_{city_slug}_{lang}"
    cached_data = cache.get(cache_key)
    is_cached = cached_data is not None
    is_fallback = False

    if cached_data:
        guide_data = cached_data
    else:
        guide_data, is_fallback = generate_guide(city_display, lang)
        cache.set(cache_key, guide_data)

    t = get_translations(lang)
    related = get_related_destinations(city_display)
    seo_title = get_seo_title(city_display, lang)
    seo_description = get_meta_description(city_display, lang)
    booking_url = (
        f"https://www.booking.com/searchresults.html"
        f"?ss={city_display.replace(' ', '+')}&lang={lang}"
    )

    hreflang_urls = {
        lc: url_for("guide", lang=lc, city=city_slug, _external=True)
        for lc in SUPPORTED_LANGUAGES
    }
    canonical_url = url_for("guide", lang=lang, city=city_slug, _external=True)

    ctx = _base_ctx(lang)
    ctx.update(
        city=city_display,
        city_slug=city_slug,
        guide_data=guide_data,
        related=related,
        seo_title=seo_title,
        seo_description=seo_description,
        booking_url=booking_url,
        hreflang_urls=hreflang_urls,
        canonical_url=canonical_url,
        is_fallback=is_fallback,
        is_cached=is_cached,
        update_time=int(time.time()),
        city_image_url=get_city_image(city_slug),
    )
    return render_template("guide.html", **ctx)

@app.route("/api/generate", methods=["POST"])
def api_generate():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid request"}), 400
    city = data.get("city", "").strip()
    language = data.get("language", "en")
    if not city:
        return jsonify({"error": "City is required"}), 400
    if language not in SUPPORTED_LANGUAGES:
        language = "en"
    city_slug = city_to_slug(city)
    cache_key = f"guide_{city_slug}_{language}"
    cached = cache.get(cache_key)
    if cached:
        return jsonify({"data": cached, "cached": True, "fallback": False})
    guide_data, is_fallback = generate_guide(city, language)
    cache.set(cache_key, guide_data)
    return jsonify({"data": guide_data, "cached": False, "fallback": is_fallback})

@app.route("/sitemap.xml")
def sitemap():
    pages = []
    base_url = request.host_url.rstrip("/")
    pages.append({"loc": base_url + "/", "priority": "1.0", "changefreq": "daily"})
    for lc in SUPPORTED_LANGUAGES:
        pages.append({"loc": f"{base_url}/{lc}/", "priority": "0.9", "changefreq": "daily"})
    for city in TOP_100_CITIES:
        cslug = city_to_slug(city)
        for lc in SUPPORTED_LANGUAGES:
            pages.append({
                "loc": f"{base_url}/{lc}/guide/{cslug}",
                "priority": "0.8",
                "changefreq": "weekly",
            })
    xml = render_template("sitemap.xml", pages=pages, now=datetime.now().strftime("%Y-%m-%d"))
    resp = make_response(xml)
    resp.headers["Content-Type"] = "application/xml"
    return resp

@app.route("/robots.txt")
def robots():
    content = f"User-agent: *\nAllow: /\nSitemap: {request.host_url}sitemap.xml\n"
    resp = make_response(content)
    resp.headers["Content-Type"] = "text/plain"
    return resp

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)

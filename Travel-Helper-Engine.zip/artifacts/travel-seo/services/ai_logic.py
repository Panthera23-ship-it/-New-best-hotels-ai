import os
import json
from datetime import datetime
from google import genai

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AIzaSyBCANQsXUbhsqjs2Ot7Nad-wEBua6NrA0g')
client = genai.Client(api_key=GEMINI_API_KEY)

LANGUAGE_NAMES = {
    "en": "English", "de": "German", "es": "Spanish", "fr": "French", "ar": "Arabic"
}

# Currency symbol to use in budget tables, keyed by UI language
LANGUAGE_CURRENCY = {
    "en": ("$", "USD"),
    "de": ("€", "EUR"),
    "es": ("€", "EUR"),
    "fr": ("€", "EUR"),
    "ar": ("$", "USD"),   # USD is internationally understood for multi-city AR guides
}

# ── Related destinations map ────────────────────────────────────────────────
RELATED_MAP = {
    "paris": ["Lyon", "Nice", "Bordeaux"],
    "rome": ["Florence", "Venice", "Milan"],
    "florence": ["Rome", "Siena", "Pisa"],
    "venice": ["Verona", "Padua", "Trieste"],
    "milan": ["Turin", "Genoa", "Bergamo"],
    "barcelona": ["Madrid", "Seville", "Valencia"],
    "madrid": ["Toledo", "Segovia", "Granada"],
    "lisbon": ["Porto", "Faro", "Sintra"],
    "amsterdam": ["Brussels", "Rotterdam", "Utrecht"],
    "berlin": ["Hamburg", "Munich", "Cologne"],
    "munich": ["Salzburg", "Vienna", "Stuttgart"],
    "vienna": ["Prague", "Budapest", "Bratislava"],
    "prague": ["Brno", "Dresden", "Krakow"],
    "budapest": ["Bratislava", "Vienna", "Belgrade"],
    "athens": ["Thessaloniki", "Heraklion", "Nafplio"],
    "santorini": ["Mykonos", "Crete", "Rhodes"],
    "istanbul": ["Ankara", "Izmir", "Cappadocia"],
    "dubai": ["Abu Dhabi", "Sharjah", "Muscat"],
    "abu dhabi": ["Dubai", "Muscat", "Doha"],
    "doha": ["Dubai", "Riyadh", "Kuwait City"],
    "riyadh": ["Jeddah", "Medina", "Doha"],
    "jeddah": ["Mecca", "Riyadh", "Taif"],
    "marrakech": ["Casablanca", "Fez", "Agadir"],
    "casablanca": ["Marrakech", "Rabat", "Tangier"],
    "cairo": ["Luxor", "Aswan", "Alexandria"],
    "nairobi": ["Mombasa", "Zanzibar", "Kampala"],
    "cape town": ["Johannesburg", "Durban", "Port Elizabeth"],
    "tokyo": ["Kyoto", "Osaka", "Hiroshima"],
    "kyoto": ["Nara", "Osaka", "Tokyo"],
    "osaka": ["Kyoto", "Kobe", "Nara"],
    "seoul": ["Busan", "Incheon", "Gyeongju"],
    "beijing": ["Shanghai", "Xi'an", "Chengdu"],
    "shanghai": ["Hangzhou", "Suzhou", "Nanjing"],
    "hong kong": ["Macau", "Shenzhen", "Guangzhou"],
    "singapore": ["Kuala Lumpur", "Batam", "Johor Bahru"],
    "kuala lumpur": ["Singapore", "Penang", "Langkawi"],
    "bangkok": ["Chiang Mai", "Phuket", "Pattaya"],
    "bali": ["Lombok", "Gili Islands", "Yogyakarta"],
    "jakarta": ["Bandung", "Yogyakarta", "Surabaya"],
    "mumbai": ["Goa", "Pune", "Ahmedabad"],
    "delhi": ["Agra", "Jaipur", "Varanasi"],
    "sydney": ["Melbourne", "Brisbane", "Gold Coast"],
    "melbourne": ["Sydney", "Adelaide", "Canberra"],
    "new york": ["Boston", "Philadelphia", "Washington DC"],
    "washington dc": ["Baltimore", "Richmond", "Philadelphia"],
    "los angeles": ["San Francisco", "Las Vegas", "San Diego"],
    "miami": ["Orlando", "Tampa", "Fort Lauderdale"],
    "chicago": ["Milwaukee", "Indianapolis", "Detroit"],
    "toronto": ["Montreal", "Ottawa", "Niagara Falls"],
    "mexico city": ["Guadalajara", "Cancun", "Oaxaca"],
    "cancun": ["Playa del Carmen", "Tulum", "Cozumel"],
    "buenos aires": ["Montevideo", "Santiago", "São Paulo"],
    "rio de janeiro": ["São Paulo", "Florianópolis", "Búzios"],
    "lima": ["Cusco", "Arequipa", "Machu Picchu"],
}

# ── Fallback templates ────────────────────────────────────────────────────────
FALLBACK_TEMPLATES = {
    "paris": {
        "itinerary": [
            {"time": "8:30 AM", "activity": "Eiffel Tower at sunrise — beat the crowds, tickets online in advance"},
            {"time": "11:00 AM", "activity": "Louvre Museum — head straight to Denon Wing for the Mona Lisa"},
            {"time": "1:00 PM", "activity": "Lunch at a Seine-side bistro in Saint-Germain-des-Prés"},
            {"time": "3:00 PM", "activity": "Notre-Dame Cathedral and Île de la Cité exploration"},
            {"time": "5:30 PM", "activity": "Montmartre neighbourhood walk and Sacré-Cœur sunset"},
            {"time": "8:00 PM", "activity": "Wine and dinner at a traditional Parisian brasserie"},
        ],
        "budget": [
            {"category": "Accommodation (3★ hotel)", "cost": "€100–€180/night"},
            {"category": "Meals (3/day)", "cost": "€35–€70/day"},
            {"category": "Metro day pass", "cost": "€8/day"},
            {"category": "Museum pass (2 days)", "cost": "€55"},
            {"category": "Shopping & extras", "cost": "€40–€120/day"},
        ],
        "faq": [
            {"q": "Is Paris expensive?", "a": "Budget travelers can manage €80/day; mid-range expect €200–€300/day including accommodation."},
            {"q": "Best time to visit Paris?", "a": "April–June and September–October for mild weather and manageable crowds."},
            {"q": "Do I need to speak French?", "a": "Tourist areas are English-friendly, but a few French phrases are warmly received."},
            {"q": "Is the Metro safe?", "a": "Generally yes — watch for pickpockets at busy stations like Châtelet-Les Halles."},
        ],
        "insider_tips": [
            "Picnic on Champ de Mars with baguette, camembert and rosé from a nearby épicerie for €12 — unbeatable Eiffel views at a fraction of restaurant prices.",
            "Visit the Louvre on Wednesday or Friday evenings (open until 9:45 PM) — crowds drop 60% after 6 PM.",
            "The Paris Museum Pass (€55) covers 50+ museums and lets you skip ticket queues — breaks even after just 3 major sites."
        ]
    },
    "tokyo": {
        "itinerary": [
            {"time": "7:00 AM", "activity": "Toyosu Market (book tuna auction months ahead) or fresh sushi breakfast"},
            {"time": "10:00 AM", "activity": "Senso-ji Temple in Asakusa and Nakamise shopping street"},
            {"time": "12:30 PM", "activity": "Ramen lunch at Shinjuku's underground ramen street in Takashimaya Times Square"},
            {"time": "2:30 PM", "activity": "Harajuku Takeshita Street and Meiji Shrine"},
            {"time": "5:00 PM", "activity": "Shibuya Crossing at dusk — best viewed from Mag's Park rooftop"},
            {"time": "8:00 PM", "activity": "Izakaya hopping through Shinjuku's Golden Gai alleyways"},
        ],
        "budget": [
            {"category": "Accommodation (capsule/budget)", "cost": "¥3,000–¥8,000/night"},
            {"category": "Meals (3/day)", "cost": "¥2,000–¥5,000/day"},
            {"category": "Suica IC card (daily)", "cost": "¥500–¥1,500"},
            {"category": "Attractions", "cost": "¥1,000–¥3,000/day"},
            {"category": "Shopping", "cost": "¥5,000–¥20,000/day"},
        ],
        "faq": [
            {"q": "Is Tokyo expensive?", "a": "Surprisingly affordable — excellent ramen from ¥800 and budget hotels from ¥3,000/night."},
            {"q": "Best way to get around?", "a": "Tokyo Metro is world-class. Load a Suica IC card (available at any station) for seamless travel."},
            {"q": "Do I need cash?", "a": "Yes — many small restaurants and bars are cash-only. 7-Eleven ATMs reliably accept foreign cards."},
            {"q": "Is Tokyo safe?", "a": "One of the safest major cities on Earth. Solo travel is very comfortable for all travellers."},
        ],
        "insider_tips": [
            "A 72-hour Tokyo Metro pass (¥1,500) offers unlimited rides — you'll save ¥2,000+ over single fares.",
            "Eat at department store basement food halls (depachika) — incredible prepared food from ¥500, zero wait.",
            "Book teamLab Borderless or teamLab Planets tickets 3–4 weeks ahead online — they sell out completely."
        ]
    },
}

def _make_default_template(city, language="en"):
    sym = LANGUAGE_CURRENCY.get(language, ("$", "USD"))[0]
    return {
        "itinerary": [
            {"time": "9:00 AM", "activity": f"Morning visit to {city}'s most iconic landmark"},
            {"time": "11:00 AM", "activity": f"Explore the best museum or historic quarter in {city}"},
            {"time": "1:00 PM", "activity": "Lunch at a highly-rated local restaurant"},
            {"time": "3:00 PM", "activity": f"Afternoon stroll through {city}'s most scenic neighbourhood"},
            {"time": "6:00 PM", "activity": f"Sunset viewpoint or rooftop bar over {city}"},
            {"time": "8:00 PM", "activity": "Dinner at a beloved local spot away from tourist traps"},
        ],
        "budget": [
            {"category": "Accommodation (mid-range)", "cost": f"{sym}80–{sym}180/night"},
            {"category": "Meals (3/day)",              "cost": f"{sym}25–{sym}60/day"},
            {"category": "Local transport",             "cost": f"{sym}5–{sym}15/day"},
            {"category": "Attractions & tours",         "cost": f"{sym}15–{sym}50/day"},
            {"category": "Shopping & extras",           "cost": f"{sym}20–{sym}80/day"},
        ],
        "faq": [
            {"q": f"Is {city} expensive?", "a": f"{city} offers options for every budget. Staying outside the tourist centre saves 30–50%."},
            {"q": f"Best time to visit {city}?", "a": "Shoulder seasons (spring and autumn) offer the best weather with fewer crowds."},
            {"q": f"Is {city} safe?", "a": f"{city} is generally safe. Stay alert in crowded areas and keep valuables secure."},
            {"q": f"How to get around {city}?", "a": "Public transport is usually the fastest and cheapest option. Research city transit passes for savings."},
        ],
        "insider_tips": [
            f"Stay one neighbourhood outside the tourist zone in {city} — 30–50% cheaper with a more authentic atmosphere.",
            f"Visit {city}'s main attractions on weekday mornings — crowds are thinnest and photos are much cleaner.",
            "Ask hostel or hotel staff (not concierges) for dining recommendations — they know the real local spots."
        ]
    }

def get_related_destinations(city):
    key = city.lower()
    for k in RELATED_MAP:
        if k in key or key in k:
            return RELATED_MAP[k]
    return ["Paris", "Tokyo", "Dubai"]

def get_meta_description(city, lang="en"):
    cache_key = f"meta_{city.lower()}_{lang}"
    descriptions = {
        "en": f"Complete {city} travel guide {datetime.now().year}: daily itinerary, honest budget breakdown, insider tips, and best hotels. Updated {datetime.now().strftime('%B %Y')}.",
        "de": f"Vollständiger Reiseführer {city} {datetime.now().year}: Tagesplan, Budgetübersicht und Insider-Tipps. Aktualisiert {datetime.now().strftime('%B %Y')}.",
        "es": f"Guía completa de {city} {datetime.now().year}: itinerario diario, presupuesto detallado y consejos exclusivos. Actualizado {datetime.now().strftime('%B %Y')}.",
        "fr": f"Guide complet {city} {datetime.now().year} : itinéraire, budget et conseils d'initiés. Mis à jour {datetime.now().strftime('%B %Y')}.",
        "ar": f"دليل سفر شامل إلى {city} {datetime.now().year}: جدول يومي وميزانية تفصيلية ونصائح حصرية. محدّث {datetime.now().strftime('%B %Y')}.",
    }
    return descriptions.get(lang, descriptions["en"])

def get_fallback(city, language="en"):
    key = city.lower()
    # For hardcoded city templates, they already have real currency baked in.
    # For unknown cities, build a generic template with the correct currency symbol.
    for k in FALLBACK_TEMPLATES:
        if k in key:
            return FALLBACK_TEMPLATES[k]
    return _make_default_template(city, language)

def generate_guide(city, language="en"):
    lang_name = LANGUAGE_NAMES.get(language, "English")
    currency_sym, currency_code = LANGUAGE_CURRENCY.get(language, ("$", "USD"))

    # Build language enforcement clause for non-English languages
    if language != "en":
        lang_enforcement = (
            f"\n\nCRITICAL LANGUAGE RULE: Every single word in ALL fields must be written in {lang_name}. "
            f"This means all activity descriptions, category names, FAQ questions and answers, and insider tips. "
            f"Do NOT write any English words anywhere in the JSON values. "
            f"If you are writing Arabic, use only Arabic script. "
            f"If you are writing German, use only German words. "
            f"If you are writing French, use only French words. "
            f"If you are writing Spanish, use only Spanish words. "
            f"The ONLY exception is the time format in the 'time' field (e.g. '9:00 AM') and numeric cost values."
        )
    else:
        lang_enforcement = ""

    # Currency instruction injected into prompt so AI uses correct symbol
    currency_instruction = (
        f"\n\nCURRENCY RULE: All costs in the 'budget' array must use {currency_code} with the "
        f"'{currency_sym}' symbol. Example format: '{currency_sym}X–{currency_sym}Y/night'. "
        f"Do NOT use any other currency symbol."
    )

    prompt = f"""Generate a comprehensive travel guide for {city}. The ENTIRE response must be in {lang_name}.{lang_enforcement}{currency_instruction}

Return ONLY a valid JSON object — no markdown, no code fences, no explanation. Use this exact structure:
{{
  "itinerary": [
    {{"time": "9:00 AM", "activity": "very specific, practical activity in {lang_name}"}},
    {{"time": "11:30 AM", "activity": "activity in {lang_name}"}},
    {{"time": "1:00 PM", "activity": "activity in {lang_name}"}},
    {{"time": "3:00 PM", "activity": "activity in {lang_name}"}},
    {{"time": "5:30 PM", "activity": "activity in {lang_name}"}},
    {{"time": "8:00 PM", "activity": "activity in {lang_name}"}}
  ],
  "budget": [
    {{"category": "category name in {lang_name}", "cost": "{currency_sym}X–{currency_sym}Y/night"}},
    {{"category": "category name in {lang_name}", "cost": "{currency_sym}X–{currency_sym}Y/night"}},
    {{"category": "category name in {lang_name}", "cost": "{currency_sym}X–{currency_sym}Y/day"}},
    {{"category": "category name in {lang_name}", "cost": "{currency_sym}X–{currency_sym}Y/day"}},
    {{"category": "category name in {lang_name}", "cost": "{currency_sym}X–{currency_sym}Y/day"}}
  ],
  "faq": [
    {{"q": "question in {lang_name}", "a": "detailed answer in {lang_name}"}},
    {{"q": "question in {lang_name}", "a": "detailed answer in {lang_name}"}},
    {{"q": "question in {lang_name}", "a": "detailed answer in {lang_name}"}},
    {{"q": "question in {lang_name}", "a": "detailed answer in {lang_name}"}}
  ],
  "insider_tips": [
    "specific money-saving or time-saving tip about {city} written entirely in {lang_name}",
    "local secret written entirely in {lang_name}",
    "practical logistical tip written entirely in {lang_name}"
  ]
}}

Be hyper-specific to {city}. Mention real neighbourhoods, real restaurant districts, real transport options. Do not be generic. Remember: ALL text values must be in {lang_name} only, and all costs must use {currency_sym} ({currency_code})."""

    try:
        response = client.models.generate_content(model='gemini-1.5-flash', contents=prompt)
        text = response.text.strip()
        if "```" in text:
            parts = text.split("```")
            text = parts[1] if len(parts) > 1 else parts[0]
            if text.startswith("json"):
                text = text[4:]
        text = text.strip()
        data = json.loads(text)
        for key in ["itinerary", "budget", "faq", "insider_tips"]:
            if key not in data:
                raise ValueError(f"Missing key: {key}")
        return data, False
    except Exception as e:
        print(f"[AI] Gemini error for {city}: {e}")
        return get_fallback(city, language), True

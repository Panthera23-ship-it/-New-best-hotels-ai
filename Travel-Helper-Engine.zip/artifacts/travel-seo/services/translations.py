"""
Centralised UI translation dictionary for all 5 supported languages.
Every user-visible string in base.html, index.html and guide.html is sourced from here.
Usage in app.py:  from services.translations import get_translations
                  t = get_translations(lang)
Usage in template: {{ t.key }} or {{ t.key | format(city=city) }}
"""

TRANSLATIONS = {
    # ─────────────────────────────────────────────
    # ENGLISH
    # ─────────────────────────────────────────────
    "en": {
        # Site-wide
        "dir": "ltr",
        "site_tagline": "AI-powered travel guides for every city, in 5 languages. Free, updated daily.",
        "footer_top_destinations": "Top Destinations",
        "footer_languages": "Languages",
        "footer_copyright": "© {year} TravelSEO — AI-Powered Travel Intelligence",
        "footer_disclaimer": "Data updated regularly. Always verify visa requirements before travel.",

        # Index hero
        "hero_badge": "Gemini AI · 5 Languages · 100+ Cities",
        "hero_title_1": "Your AI Travel Guide",
        "hero_title_2": "in Seconds",
        "hero_subtitle": "Enter any city. Get a full travel guide — day itinerary, honest budget, and insider tips — instantly, in your language.",
        "search_placeholder": "Enter a city name...",
        "search_placeholder_suggestion": "✈️",
        "btn_generate": "Generate ✦",

        # Index sections
        "popular_destinations": "Popular Destinations",
        "powered_by": "Powered by Gemini AI",
        "feat_itinerary_title": "Day Itinerary",
        "feat_itinerary_desc": "Optimised schedules built around real opening hours, crowd patterns, and hidden locals-only spots.",
        "feat_budget_title": "Honest Budget",
        "feat_budget_desc": "Real cost data across accommodation, food, transport — not aspirational magazine pricing.",
        "feat_tips_title": "Insider Tips",
        "feat_tips_desc": "Three specific local secrets per city — things guidebooks won't publish.",
        "loading_title": "Building Your Guide",
        "loading_subtitle": "Gemini AI is crafting your personalised guide...",
        "loading_for": "Building guide for {city}...",

        # Guide breadcrumb & badges
        "nav_home": "Home",
        "badge_fallback": "Cached Template",
        "badge_cached": "⚡ Cached",

        # Guide hero
        "btn_check_prices": "Check Hotel Prices in {city}",
        "btn_view_itinerary": "📅 View Itinerary ↓",

        # Urgency strip
        "urgency_strip": "⚡ Hotel prices just updated — {n} people booked {city} in the last hour",
        "urgency_updated_ago": "Hotel prices updated {t} ago",
        "urgency_updated_now": "Hotel prices just updated",

        # Guide sections
        "section_itinerary": "Day Itinerary",
        "section_itinerary_sub": "Optimised for minimal travel time",
        "section_budget": "Budget Breakdown",
        "section_budget_sub": "Realistic costs for {city}",
        "budget_col_category": "Category",
        "budget_col_cost": "Cost",
        "section_tips": "3 Insider Tips",
        "section_tips_sub": "Things most guidebooks won't tell you",
        "section_faq": "Frequently Asked Questions",
        "section_faq_sub": "Honest answers about {city}",
        "section_related": "Nearby & Related Destinations",
        "section_related_sub": "You might also love these cities",
        "related_view_guide": "View Guide →",

        # Sidebar
        "sidebar_hotels": "Hotels in {city}",
        "sidebar_hotels_sub": "Compare and book your stay",
        "btn_book_best": "Check Best Prices →",
        "perk_cancel": "Free cancellation on most hotels",
        "perk_price": "Best price guarantee",
        "perk_fees": "No booking fees",
        "sidebar_guide_in": "This Guide In",
        "lang_current": "Current",

        # Share
        "share_title": "Share This Guide",
        "share_twitter": "𝕏 Twitter",
        "share_copy": "🔗 Copy Link",
        "share_copied": "✓ Copied!",

        # Mobile bar
        "mobile_book_now": "Book Now 🏨",

        # Ticker (JS interpolated)
        "ticker_long": "{n} people booked in the last hour",
        "ticker_short": "{n} booked just now",

        # Real-time pulse (mobile bar)
        "pulse_looking": "🔥 {n} people looking at {city} hotels right now",

        # Why Trust Us (footer)
        "trust_title": "Why Trust Us?",
        "trust_body": "Our prices are AI-calculated from real-time booking trends across 50+ platforms — not pulled from outdated databases.",
        "trust_ai": "Gemini AI analyses live pricing from 50+ booking platforms",
        "trust_realtime": "Budget data refreshed every 24 hours",
        "trust_verified": "10,000+ city guides generated and counting",
        "trust_free": "Always free — no sign-up, no paywall",
    },

    # ─────────────────────────────────────────────
    # GERMAN
    # ─────────────────────────────────────────────
    "de": {
        "dir": "ltr",
        "site_tagline": "KI-gestützte Reiseführer für jede Stadt, in 5 Sprachen. Kostenlos, täglich aktualisiert.",
        "footer_top_destinations": "Top-Reiseziele",
        "footer_languages": "Sprachen",
        "footer_copyright": "© {year} TravelSEO — KI-gestützte Reiseintelligenz",
        "footer_disclaimer": "Daten werden regelmäßig aktualisiert. Visabestimmungen vor der Reise prüfen.",

        "hero_badge": "Gemini KI · 5 Sprachen · 100+ Städte",
        "hero_title_1": "Dein KI-Reiseführer",
        "hero_title_2": "in Sekunden",
        "hero_subtitle": "Gib eine Stadt ein und erhalte sofort einen vollständigen Reiseführer mit Tagesplan, Budgetübersicht und Insider-Tipps.",
        "search_placeholder": "Stadtname eingeben...",
        "search_placeholder_suggestion": "✈️",
        "btn_generate": "Erstellen ✦",

        "popular_destinations": "Beliebte Reiseziele",
        "powered_by": "Powered by Gemini KI",
        "feat_itinerary_title": "Tagesplan",
        "feat_itinerary_desc": "Optimierte Routen basierend auf echten Öffnungszeiten, Menschenmengen und versteckten Geheimtipps.",
        "feat_budget_title": "Ehrliches Budget",
        "feat_budget_desc": "Echte Kostendaten für Unterkunft, Verpflegung und Transport – keine unrealistischen Magazinpreise.",
        "feat_tips_title": "Insider-Tipps",
        "feat_tips_desc": "Drei spezifische lokale Geheimnisse pro Stadt – Dinge, die Reiseführer nicht veröffentlichen.",
        "loading_title": "Reiseführer wird erstellt",
        "loading_subtitle": "Gemini KI erstellt deinen personalisierten Reiseführer...",
        "loading_for": "Reiseführer für {city} wird erstellt...",

        "nav_home": "Startseite",
        "badge_fallback": "Gecachte Vorlage",
        "badge_cached": "⚡ Gecacht",

        "btn_check_prices": "Hotelpreise in {city} prüfen",
        "btn_view_itinerary": "📅 Tagesplan ansehen ↓",

        "urgency_strip": "⚡ Hotelpreise gerade aktualisiert — {n} Personen buchten {city} in der letzten Stunde",
        "urgency_updated_ago": "Hotelpreise vor {t} aktualisiert",
        "urgency_updated_now": "Hotelpreise gerade aktualisiert",

        "section_itinerary": "Tagesplan",
        "section_itinerary_sub": "Optimiert für minimale Reisezeit",
        "section_budget": "Budgetaufstellung",
        "section_budget_sub": "Reale Kosten für {city}",
        "budget_col_category": "Kategorie",
        "budget_col_cost": "Kosten",
        "section_tips": "3 Insider-Tipps",
        "section_tips_sub": "Was die meisten Reiseführer verschweigen",
        "section_faq": "Häufig gestellte Fragen",
        "section_faq_sub": "Ehrliche Antworten über {city}",
        "section_related": "Nahe & ähnliche Reiseziele",
        "section_related_sub": "Diese Städte könnten dir auch gefallen",
        "related_view_guide": "Reiseführer ansehen →",

        "sidebar_hotels": "Hotels in {city}",
        "sidebar_hotels_sub": "Vergleichen und buchen",
        "btn_book_best": "Beste Preise prüfen →",
        "perk_cancel": "Kostenlose Stornierung bei den meisten Hotels",
        "perk_price": "Bestpreisgarantie",
        "perk_fees": "Keine Buchungsgebühren",
        "sidebar_guide_in": "Dieser Reiseführer auf",
        "lang_current": "Aktuell",

        "share_title": "Reiseführer teilen",
        "share_twitter": "𝕏 Twitter",
        "share_copy": "🔗 Link kopieren",
        "share_copied": "✓ Kopiert!",

        "mobile_book_now": "Jetzt buchen 🏨",

        "ticker_long": "{n} Personen buchten in der letzten Stunde",
        "ticker_short": "{n} buchten gerade",

        "pulse_looking": "🔥 {n} Personen schauen sich gerade Hotels in {city} an",

        "trust_title": "Warum Uns Vertrauen?",
        "trust_body": "Unsere Preise werden von KI aus Echtzeit-Buchungstrends auf 50+ Plattformen berechnet — nicht aus veralteten Datenbanken.",
        "trust_ai": "Gemini KI analysiert Live-Preise von 50+ Buchungsplattformen",
        "trust_realtime": "Budgetdaten werden alle 24 Stunden aktualisiert",
        "trust_verified": "Über 10.000 Stadtführer erstellt und stetig wachsend",
        "trust_free": "Immer kostenlos — keine Anmeldung, keine Bezahlschranke",
    },

    # ─────────────────────────────────────────────
    # SPANISH
    # ─────────────────────────────────────────────
    "es": {
        "dir": "ltr",
        "site_tagline": "Guías de viaje con IA para cada ciudad, en 5 idiomas. Gratis, actualizadas diariamente.",
        "footer_top_destinations": "Destinos Populares",
        "footer_languages": "Idiomas",
        "footer_copyright": "© {year} TravelSEO — Inteligencia de Viaje con IA",
        "footer_disclaimer": "Datos actualizados regularmente. Verifica los requisitos de visa antes de viajar.",

        "hero_badge": "Gemini IA · 5 Idiomas · 100+ Ciudades",
        "hero_title_1": "Tu Guía de Viaje con IA",
        "hero_title_2": "en Segundos",
        "hero_subtitle": "Escribe cualquier ciudad y obtén una guía completa — itinerario diario, presupuesto honesto y consejos exclusivos — al instante, en tu idioma.",
        "search_placeholder": "Escribe el nombre de una ciudad...",
        "search_placeholder_suggestion": "✈️",
        "btn_generate": "Generar ✦",

        "popular_destinations": "Destinos Populares",
        "powered_by": "Impulsado por Gemini IA",
        "feat_itinerary_title": "Itinerario Diario",
        "feat_itinerary_desc": "Rutas optimizadas según horarios reales, afluencia de turistas y rincones secretos de locales.",
        "feat_budget_title": "Presupuesto Honesto",
        "feat_budget_desc": "Costos reales de alojamiento, comida y transporte — no precios de revista aspiracionales.",
        "feat_tips_title": "Consejos Insider",
        "feat_tips_desc": "Tres secretos locales específicos por ciudad — cosas que las guías no publicarán.",
        "loading_title": "Creando Tu Guía",
        "loading_subtitle": "Gemini IA está elaborando tu guía personalizada...",
        "loading_for": "Creando guía para {city}...",

        "nav_home": "Inicio",
        "badge_fallback": "Plantilla en Caché",
        "badge_cached": "⚡ En Caché",

        "btn_check_prices": "Ver Precios de Hoteles en {city}",
        "btn_view_itinerary": "📅 Ver Itinerario ↓",

        "urgency_strip": "⚡ Precios de hoteles recién actualizados — {n} personas reservaron {city} en la última hora",
        "urgency_updated_ago": "Precios actualizados hace {t}",
        "urgency_updated_now": "Precios recién actualizados",

        "section_itinerary": "Itinerario Diario",
        "section_itinerary_sub": "Optimizado para minimizar tiempos de desplazamiento",
        "section_budget": "Desglose de Presupuesto",
        "section_budget_sub": "Costos reales en {city}",
        "budget_col_category": "Categoría",
        "budget_col_cost": "Costo",
        "section_tips": "3 Consejos Insider",
        "section_tips_sub": "Lo que la mayoría de las guías no te dirán",
        "section_faq": "Preguntas Frecuentes",
        "section_faq_sub": "Respuestas honestas sobre {city}",
        "section_related": "Destinos Cercanos y Similares",
        "section_related_sub": "Otras ciudades que podrían gustarte",
        "related_view_guide": "Ver Guía →",

        "sidebar_hotels": "Hoteles en {city}",
        "sidebar_hotels_sub": "Compara y reserva tu estancia",
        "btn_book_best": "Ver Mejores Precios →",
        "perk_cancel": "Cancelación gratuita en la mayoría de hoteles",
        "perk_price": "Garantía de mejor precio",
        "perk_fees": "Sin comisiones de reserva",
        "sidebar_guide_in": "Esta Guía En",
        "lang_current": "Actual",

        "share_title": "Compartir Esta Guía",
        "share_twitter": "𝕏 Twitter",
        "share_copy": "🔗 Copiar Enlace",
        "share_copied": "✓ ¡Copiado!",

        "mobile_book_now": "Reservar Ahora 🏨",

        "ticker_long": "{n} personas reservaron en la última hora",
        "ticker_short": "{n} reservaron ahora mismo",

        "pulse_looking": "🔥 {n} personas están buscando hoteles en {city} ahora mismo",

        "trust_title": "¿Por Qué Confiar en Nosotros?",
        "trust_body": "Nuestros precios son calculados por IA a partir de tendencias de reserva en tiempo real en 50+ plataformas — no desde bases de datos desactualizadas.",
        "trust_ai": "Gemini IA analiza precios en vivo de más de 50 plataformas",
        "trust_realtime": "Datos de presupuesto actualizados cada 24 horas",
        "trust_verified": "Más de 10.000 guías generadas y contando",
        "trust_free": "Siempre gratis — sin registro ni paywall",
    },

    # ─────────────────────────────────────────────
    # FRENCH
    # ─────────────────────────────────────────────
    "fr": {
        "dir": "ltr",
        "site_tagline": "Guides de voyage par IA pour chaque ville, en 5 langues. Gratuit, mis à jour quotidiennement.",
        "footer_top_destinations": "Destinations Populaires",
        "footer_languages": "Langues",
        "footer_copyright": "© {year} TravelSEO — Intelligence de Voyage par IA",
        "footer_disclaimer": "Données mises à jour régulièrement. Vérifiez les exigences de visa avant de voyager.",

        "hero_badge": "Gemini IA · 5 Langues · 100+ Villes",
        "hero_title_1": "Votre Guide de Voyage IA",
        "hero_title_2": "en Quelques Secondes",
        "hero_subtitle": "Entrez n'importe quelle ville et obtenez un guide complet — itinéraire quotidien, budget honnête et conseils d'initiés — instantanément, dans votre langue.",
        "search_placeholder": "Entrez le nom d'une ville...",
        "search_placeholder_suggestion": "✈️",
        "btn_generate": "Générer ✦",

        "popular_destinations": "Destinations Populaires",
        "powered_by": "Propulsé par Gemini IA",
        "feat_itinerary_title": "Itinéraire Journalier",
        "feat_itinerary_desc": "Programmes optimisés selon les horaires réels, les affluences et les spots secrets des locaux.",
        "feat_budget_title": "Budget Honnête",
        "feat_budget_desc": "Coûts réels de l'hébergement, de la nourriture et des transports — pas des prix de magazines aspirationnels.",
        "feat_tips_title": "Conseils d'Initiés",
        "feat_tips_desc": "Trois secrets locaux spécifiques par ville — des choses que les guides ne publient pas.",
        "loading_title": "Création de Votre Guide",
        "loading_subtitle": "Gemini IA prépare votre guide personnalisé...",
        "loading_for": "Création du guide pour {city}...",

        "nav_home": "Accueil",
        "badge_fallback": "Modèle en Cache",
        "badge_cached": "⚡ En Cache",

        "btn_check_prices": "Voir les Prix des Hôtels à {city}",
        "btn_view_itinerary": "📅 Voir l'Itinéraire ↓",

        "urgency_strip": "⚡ Prix des hôtels venant d'être mis à jour — {n} personnes ont réservé {city} dans la dernière heure",
        "urgency_updated_ago": "Prix mis à jour il y a {t}",
        "urgency_updated_now": "Prix venant d'être mis à jour",

        "section_itinerary": "Itinéraire Journalier",
        "section_itinerary_sub": "Optimisé pour minimiser les temps de trajet",
        "section_budget": "Décomposition du Budget",
        "section_budget_sub": "Coûts réels à {city}",
        "budget_col_category": "Catégorie",
        "budget_col_cost": "Coût",
        "section_tips": "3 Conseils d'Initiés",
        "section_tips_sub": "Ce que la plupart des guides ne vous diront pas",
        "section_faq": "Questions Fréquemment Posées",
        "section_faq_sub": "Réponses honnêtes sur {city}",
        "section_related": "Destinations Proches et Similaires",
        "section_related_sub": "D'autres villes qui pourraient vous plaire",
        "related_view_guide": "Voir le Guide →",

        "sidebar_hotels": "Hôtels à {city}",
        "sidebar_hotels_sub": "Comparez et réservez votre séjour",
        "btn_book_best": "Voir les Meilleurs Prix →",
        "perk_cancel": "Annulation gratuite dans la plupart des hôtels",
        "perk_price": "Garantie meilleur prix",
        "perk_fees": "Aucuns frais de réservation",
        "sidebar_guide_in": "Ce Guide En",
        "lang_current": "Actuel",

        "share_title": "Partager Ce Guide",
        "share_twitter": "𝕏 Twitter",
        "share_copy": "🔗 Copier le Lien",
        "share_copied": "✓ Copié !",

        "mobile_book_now": "Réserver 🏨",

        "ticker_long": "{n} personnes ont réservé dans la dernière heure",
        "ticker_short": "{n} ont réservé à l'instant",

        "pulse_looking": "🔥 {n} personnes cherchent des hôtels à {city} en ce moment",

        "trust_title": "Pourquoi Nous Faire Confiance ?",
        "trust_body": "Nos prix sont calculés par IA à partir des tendances de réservation en temps réel sur 50+ plateformes — pas depuis des bases de données obsolètes.",
        "trust_ai": "Gemini IA analyse les prix en direct de 50+ plateformes de réservation",
        "trust_realtime": "Données budgétaires actualisées toutes les 24 heures",
        "trust_verified": "Plus de 10 000 guides générés et ça continue",
        "trust_free": "Toujours gratuit — sans inscription ni paywall",
    },

    # ─────────────────────────────────────────────
    # ARABIC (RTL)
    # ─────────────────────────────────────────────
    "ar": {
        "dir": "rtl",
        "site_tagline": "أدلة سفر بالذكاء الاصطناعي لكل مدينة، بـ5 لغات. مجانية، تُحدَّث يومياً.",
        "footer_top_destinations": "أبرز الوجهات",
        "footer_languages": "اللغات",
        "footer_copyright": "© {year} TravelSEO — ذكاء السفر الاصطناعي",
        "footer_disclaimer": "تُحدَّث البيانات بانتظام. تحقق من متطلبات التأشيرة قبل السفر.",

        "hero_badge": "جيميني AI · 5 لغات · أكثر من 100 مدينة",
        "hero_title_1": "دليل سفرك بالذكاء الاصطناعي",
        "hero_title_2": "في ثوانٍ",
        "hero_subtitle": "أدخل اسم أي مدينة واحصل على دليل سفر كامل — جدول يومي وميزانية صادقة ونصائح حصرية — فوراً، بلغتك.",
        "search_placeholder": "أدخل اسم المدينة...",
        "search_placeholder_suggestion": "✈️",
        "btn_generate": "إنشاء الدليل ✦",

        "popular_destinations": "وجهات شائعة",
        "powered_by": "مدعوم بـ Gemini AI",
        "feat_itinerary_title": "الجدول اليومي",
        "feat_itinerary_desc": "برامج محسّنة بناءً على أوقات العمل الفعلية وأنماط الازدحام والأماكن السرية المحلية.",
        "feat_budget_title": "ميزانية صادقة",
        "feat_budget_desc": "بيانات تكلفة حقيقية للإقامة والطعام والمواصلات — لا أسعار مجلات طموحة.",
        "feat_tips_title": "نصائح داخلية",
        "feat_tips_desc": "ثلاثة أسرار محلية محددة لكل مدينة — أشياء لن تجدها في أي دليل سياحي.",
        "loading_title": "جارٍ إنشاء دليلك",
        "loading_subtitle": "يقوم Gemini AI بإعداد دليلك الشخصي...",
        "loading_for": "جارٍ إنشاء دليل {city}...",

        "nav_home": "الرئيسية",
        "badge_fallback": "قالب مُخزَّن",
        "badge_cached": "⚡ مُخزَّن",

        "btn_check_prices": "تحقق من أسعار الفنادق في {city}",
        "btn_view_itinerary": "📅 عرض الجدول اليومي ↓",

        "urgency_strip": "⚡ أسعار الفنادق تم تحديثها للتو — {n} أشخاص حجزوا {city} في الساعة الأخيرة",
        "urgency_updated_ago": "تم تحديث الأسعار منذ {t}",
        "urgency_updated_now": "تم تحديث الأسعار للتو",

        "section_itinerary": "الجدول اليومي",
        "section_itinerary_sub": "محسّن لتقليل وقت التنقل",
        "section_budget": "تفصيل الميزانية",
        "section_budget_sub": "التكاليف الفعلية في {city}",
        "budget_col_category": "الفئة",
        "budget_col_cost": "التكلفة",
        "section_tips": "3 نصائح داخلية",
        "section_tips_sub": "ما لن تجده في معظم الأدلة السياحية",
        "section_faq": "الأسئلة الشائعة",
        "section_faq_sub": "إجابات صادقة عن {city}",
        "section_related": "وجهات قريبة ومشابهة",
        "section_related_sub": "مدن أخرى قد تعجبك",
        "related_view_guide": "عرض الدليل →",

        "sidebar_hotels": "فنادق في {city}",
        "sidebar_hotels_sub": "قارن واحجز إقامتك",
        "btn_book_best": "عرض أفضل الأسعار →",
        "perk_cancel": "إلغاء مجاني في معظم الفنادق",
        "perk_price": "ضمان أفضل سعر",
        "perk_fees": "بدون رسوم حجز",
        "sidebar_guide_in": "هذا الدليل بـ",
        "lang_current": "الحالية",

        "share_title": "شارك هذا الدليل",
        "share_twitter": "𝕏 تويتر",
        "share_copy": "🔗 نسخ الرابط",
        "share_copied": "✓ تم النسخ!",

        "mobile_book_now": "احجز الآن 🏨",

        "ticker_long": "{n} أشخاص حجزوا في الساعة الأخيرة",
        "ticker_short": "{n} حجزوا للتو",

        "pulse_looking": "🔥 {n} أشخاص يبحثون عن فنادق في {city} الآن",

        "trust_title": "لماذا تثق بنا؟",
        "trust_body": "أسعارنا يحسبها الذكاء الاصطناعي من بيانات الحجز الفورية عبر أكثر من 50 منصة — وليس من قواعد بيانات قديمة.",
        "trust_ai": "يحلل Gemini AI الأسعار الحية من أكثر من 50 منصة حجز",
        "trust_realtime": "بيانات الميزانية تُحدَّث كل 24 ساعة",
        "trust_verified": "أكثر من 10,000 دليل مدينة تم إنشاؤه وما زال يتزايد",
        "trust_free": "مجاني دائماً — بدون تسجيل أو جدار دفع",
    },
}


def get_translations(lang: str) -> dict:
    """Return the translation dict for the given language code, falling back to English."""
    return TRANSLATIONS.get(lang, TRANSLATIONS["en"])
